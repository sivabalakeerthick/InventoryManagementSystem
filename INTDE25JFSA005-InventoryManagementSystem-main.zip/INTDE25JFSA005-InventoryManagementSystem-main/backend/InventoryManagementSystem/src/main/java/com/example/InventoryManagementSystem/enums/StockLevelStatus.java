package com.example.InventoryManagementSystem.enums;

public enum StockLevelStatus {
    IN_STOCK,
    LOW_STOCK,
    OUT_OF_STOCK,
    NOT_AVAILABLE
}
