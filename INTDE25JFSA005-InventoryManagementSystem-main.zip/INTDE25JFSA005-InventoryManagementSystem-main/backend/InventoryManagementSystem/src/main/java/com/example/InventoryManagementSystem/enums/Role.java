package com.example.InventoryManagementSystem.enums;

public enum Role {
    ADMIN,
    STAFF
}
