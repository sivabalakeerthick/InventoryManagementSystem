package com.example.InventoryManagementSystem.enums;

public enum PurchaseOrderStatus {
    PENDING, SHIPPED, DELIVERED
}
