package com.example.InventoryManagementSystem.dto.responseDTO;

public class SupplierResponseDTO {

    private Long supplierId;
    private String name;
    private Long contact;

    public Long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Long supplierId) {
        this.supplierId = supplierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getContact() {
        return contact;
    }

    public void setContact(Long contact) {
        this.contact = contact;
    }
}