package com.example.InventoryManagementSystem.dto.responseDTO;

public class PurchaseOrderItemResponseDTO {

    private String productName;
    private Long quantity;
    private Double amount;


    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getQuantity() {
        return quantity;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
