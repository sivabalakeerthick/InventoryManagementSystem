package com.example.InventoryManagementSystem.enums;

public enum UserRole {
    ADMIN,
    STAFF
}
