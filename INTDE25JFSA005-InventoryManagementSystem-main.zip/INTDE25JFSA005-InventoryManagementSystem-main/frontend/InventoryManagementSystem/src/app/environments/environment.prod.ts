export const environment = {
  production: true,
  apiUrl: 'https://api.yourproductiondomain.com', // Your production backend URL
  debugMode: false
};