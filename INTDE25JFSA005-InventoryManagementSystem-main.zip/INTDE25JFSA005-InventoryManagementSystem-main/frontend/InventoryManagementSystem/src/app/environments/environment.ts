export const environment = {
  production: false, // Indicates this is the development environment
  apiUrl: 'http://localhost:8080',
  debugMode: true
};