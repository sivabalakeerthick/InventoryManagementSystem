export interface Category{
    id?: number;
    categoryName: string;
}