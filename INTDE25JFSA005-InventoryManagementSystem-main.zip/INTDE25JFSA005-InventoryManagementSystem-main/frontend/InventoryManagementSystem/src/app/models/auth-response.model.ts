export interface AuthResponse{
    token : string,
    userRole : string
}